<?php /* incluye tu CSS principal global */ ?>
<link rel="stylesheet" href="public/css/manego.css">
