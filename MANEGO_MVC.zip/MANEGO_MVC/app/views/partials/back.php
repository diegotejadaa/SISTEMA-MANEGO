<?php
// Botón Volver reutilizable
?>
<a href="#" onclick="history.back(); return false;" title="Volver"
   style="margin-left:12px; padding:6px 10px; border:1px solid #2a2a2a; border-radius:10px; background:#111; color:#fff; text-decoration:none; display:inline-flex; align-items:center; gap:6px;">
  ← Volver
</a>
